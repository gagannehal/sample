package com.nexus.avro;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.avro.Schema;
import org.apache.avro.file.DataFileReader;
import org.apache.avro.file.DataFileWriter;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericDatumWriter;
import org.apache.avro.generic.GenericRecord;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@SpringBootApplication
public class AvroApplication implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(AvroApplication.class, args);
    }

    @Override
    public void run(String... args) throws IOException {
        String schemaFilePath = "src/main/resources/sample.avsc";
        String jsonFilePath = "src/main/resources/sample.json";
        String avroFilePath = "src/main/resources/sample.avro";

        // Convert JSON to Avro
        jsonToAvro(schemaFilePath, jsonFilePath, avroFilePath);

        // Convert Avro back to JSON
        avroToJson(avroFilePath);
    }

    private void jsonToAvro(String schemaFilePath, String jsonFilePath, String avroFilePath) throws IOException {
        // Load Avro schema
        Schema schema = new Schema.Parser().parse(new File(schemaFilePath));

        // Read JSON input into a map
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, Object> jsonMap = objectMapper.readValue(new File(jsonFilePath), Map.class);

        // Create GenericRecord and populate it
        GenericRecord record = new GenericData.Record(schema);
        for (Schema.Field field : schema.getFields()) {
            record.put(field.name(), jsonMap.get(field.name()));
        }

        // Write the record to Avro file
        try (DataFileWriter<GenericRecord> dataFileWriter = new DataFileWriter<>(new GenericDatumWriter<>(schema))) {
            dataFileWriter.create(schema, new File(avroFilePath));
            dataFileWriter.append(record);
        }

        System.out.println("JSON to Avro conversion completed. Output file: " + avroFilePath);
    }


    private void avroToJson(String avroFilePath) throws IOException {
        // Load Avro schema
        Schema schema = new Schema.Parser().parse(new File("src/main/resources/sample.avsc"));
    
        // Read Avro data and convert to JSON
        try (DataFileReader<GenericRecord> dataFileReader = new DataFileReader<>(new File(avroFilePath), new GenericDatumReader<>(schema))) {
            while (dataFileReader.hasNext()) {
                GenericRecord record = dataFileReader.next();
    
                // Convert GenericRecord to JSON
                ObjectMapper objectMapper = new ObjectMapper();
                Map<String, Object> recordMap = new HashMap<>();
                for (Schema.Field field : schema.getFields()) {
                    recordMap.put(field.name(), record.get(field.name()));
                }
    
                // Print JSON output
                System.out.println(objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(recordMap));
            }
        }
    
        System.out.println("Avro to JSON conversion completed.");
    }
    
}
