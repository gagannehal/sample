package com.nexus.staedi;

import io.xlate.edi.stream.EDIInputFactory;
import io.xlate.edi.stream.EDIStreamEvent;
import io.xlate.edi.stream.EDIStreamException;
import io.xlate.edi.stream.EDIStreamReader;
import io.xlate.edi.stream.EDIStreamWriter;
import io.xlate.edi.stream.EDIOutputFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SpringBootApplication
public class StaediApplication implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(StaediApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        String jsonFilePath = "src/main/resources/sampleInput.json";
        String ediOutputFilePath = "src/main/resources/sampleOutput.edi";

        String jsonOutputFilePath = "src/main/resources/sampleOutput.json";
        String ediFilePath = "src/main/resources/sampleInput.edi";

        // Convert JSON to EDI
        jsonToEdi(jsonFilePath, ediOutputFilePath);

        // Convert EDI to JSON
        ediToJson(ediFilePath,jsonOutputFilePath);
    }

    private void ediToJson(String ediFilePath, String jsonOutputPath) throws IOException, EDIStreamException {
        Map<String, List<String>> jsonData = new HashMap<>();
    
        InputStream inputStream = null;
        EDIStreamReader reader = null;
    
        try {
            inputStream = new FileInputStream(ediFilePath);
            reader = EDIInputFactory.newFactory().createEDIStreamReader(inputStream);
    
            String currentSegment = null;
    
            while (reader.hasNext()) {
                EDIStreamEvent event = reader.next();
                System.out.println("Processing event: " + event);
                if (event == EDIStreamEvent.START_SEGMENT) {
                    String segment = reader.getText();
                    System.out.println("Start segment: " + segment);  // Log the segment name
                    currentSegment = segment;
                    jsonData.putIfAbsent(currentSegment, new ArrayList<>());
                } else if (event == EDIStreamEvent.ELEMENT_DATA && currentSegment != null) {
                    String element = reader.getText();
                    System.out.println("Element: " + element);  // Log the element being processed
                    jsonData.get(currentSegment).add(element);
                }
                // Check for unexpected end of stream
                if (!reader.hasNext() && currentSegment != null) {
                    System.out.println("Unexpected end of stream encountered at segment: " + currentSegment);
                }
            }
    
            // Convert to JSON and write to file
            ObjectMapper objectMapper = new ObjectMapper();
            File outputFile = new File(jsonOutputPath);
            objectMapper.writerWithDefaultPrettyPrinter().writeValue(outputFile, jsonData);
            System.out.println("EDI to JSON conversion completed. Output file: " + jsonOutputPath);
    
        } catch (EDIStreamException e) {
            System.err.println("Error processing EDI file: " + e.getMessage());
            throw e;
        } finally {
            if (reader != null) {
                reader.close();
            }
            if (inputStream != null) {
                inputStream.close();
            }
        }
    }
    
    private void jsonToEdi(String jsonFilePath, String ediFilePath) throws IOException, EDIStreamException {
     // Read JSON data from the file
     ObjectMapper objectMapper = new ObjectMapper();
     Map<String, Object> jsonData = objectMapper.readValue(new File(jsonFilePath), Map.class);

     OutputStream outputStream = null;
     EDIStreamWriter writer = null;

     try {
         // Create an output stream to the EDI file
         outputStream = new FileOutputStream(ediFilePath);
         writer = EDIOutputFactory.newFactory().createEDIStreamWriter(outputStream);

         // Start interchange (ISA segment)
         writer.startInterchange();
         writer.writeStartSegment("ISA");
         writeSegment(writer, "ISA", jsonData.get("ISA"));
         writer.writeEndSegment();


         // Start GS segment
        writer.writeStartSegment("GS");
        writeSegment(writer, "GS", jsonData.get("GS"));
        writer.writeEndSegment();

         // Conversion completed
         System.out.println("EDI file has been generated: " + ediFilePath);

     } finally {
         if (writer != null) {
             writer.close();
         }
         if (outputStream != null) {
             outputStream.close();
         }
     }
    }

    private static void writeSegment(EDIStreamWriter writer, String segmentName, Object segmentData) throws EDIStreamException {
        if (segmentData == null) {
            System.err.println("Warning: Segment " + segmentName + " is missing or null");
            return; // Skip the segment if data is missing
        }

        // Handle ArrayList type
        if (segmentData instanceof ArrayList) {
            ArrayList<?> dataList = (ArrayList<?>) segmentData;  // Cast to ArrayList
            for (Object element : dataList) {
                if (element != null) {
                    writer.writeElement(element.toString()); // Convert element to string and write it
                }
            }
        }
        // Handle String[] (Array of Strings) type
        else if (segmentData instanceof String[]) {
            for (String element : (String[]) segmentData) {
                if (element != null) {
                    writer.writeElement(element);
                }
            }
        }
        // Handle String type
        else if (segmentData instanceof String) {
            writer.writeElement((String) segmentData);
        } else {
            System.err.println("Warning: Segment " + segmentName + " has unexpected data type");
        }
    }
    
}
