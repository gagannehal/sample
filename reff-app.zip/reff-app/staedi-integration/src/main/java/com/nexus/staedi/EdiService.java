package com.nexus.staedi;


import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

@Service
public class EdiService {

        public Map<String, String> parseEDI(InputStream ediStream) throws Exception {
            Map<String, String> data = new HashMap<>();

            try (EDIReader reader = StaEDIStreamReaderFactory.createReader(ediStream)) {
                while (reader.hasNext()) {
                    int eventType = reader.next();

                    if (eventType == EDIStreamReader.ELEMENT_DATA) {
                        String tag = reader.getText();
                        String value = reader.getElementData();

                        data.put(tag, value);
                    }
                }
            }

            return data;
        }

        public void generateEDI(OutputStream outputStream) throws Exception {
        try (EDIStreamWriter writer = StaEDIStreamWriterFactory.createWriter(outputStream)) {
            writer.startInterchange();
            writer.writeSegment("ISA", "00", "", "00", "", "ZZ", "SENDERID", "ZZ", "RECEIVERID", "201231", "1253", "U", "00401", "000000001", "0", "P", ":");
            writer.writeSegment("GS", "IN", "SENDERID", "RECEIVERID", "20231231", "1253", "1", "X", "004010");
            writer.writeSegment("ST", "850", "0001");
            writer.writeSegment("SE", "2", "0001");
            writer.writeSegment("GE", "1", "1");
            writer.writeSegment("IEA", "1", "000000001");
            writer.endInterchange();
        }
    }

}