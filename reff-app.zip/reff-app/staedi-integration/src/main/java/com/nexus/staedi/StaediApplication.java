package com.nexus.staedi;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class StaediApplication {

	public static void main(String[] args) {
		SpringApplication.run(StaediApplication.class, args);
	}

	@GetMapping("/healthcheck")
	public String healthcheck() {
		return "OK";
	}

	@Autowired
    private EdiService ediService;

    @PostMapping("/parse")
    public ResponseEntity<Map<String, String>> parseEDI(@RequestBody byte[] ediFile) throws Exception {
        ByteArrayInputStream inputStream = new ByteArrayInputStream(ediFile);
        Map<String, String> data = ediService.parseEDI(inputStream);
        return ResponseEntity.ok(data);
    }

    @GetMapping("/generate")
    public ResponseEntity<byte[]> generateEDI() throws Exception {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        ediService.generateEDI(outputStream);
        return ResponseEntity.ok(outputStream.toByteArray());
    }

}
