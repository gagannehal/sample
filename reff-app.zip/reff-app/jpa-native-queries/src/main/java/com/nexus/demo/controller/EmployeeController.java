package com.nexus.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.nexus.demo.entity.Employee;
import com.nexus.demo.repository.EmployeeRepository;
import com.nexus.demo.service.EmployeeService;

import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private EmployeeService employeeService;

    @PostMapping
    public Employee createEmployee(@RequestBody Employee employee) {
        return employeeRepository.save(employee);
    }

    @GetMapping
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    @GetMapping("/salary/{salary}")
    public List<Employee> getEmployeesWithSalaryGreaterThan(@PathVariable double salary) {
        return employeeRepository.findEmployeesWithSalaryGreaterThan(salary);
    }

    @GetMapping("/department/{department}")
    public List<Employee> getEmployeesByDepartment(@PathVariable String department) {
        return employeeRepository.findEmployeesByDepartment(department);
    }

    @GetMapping("/criteria/{department}")
    public List<Employee> getEmployeesUsingCriteria(@PathVariable String department) {
        return employeeService.findEmployeesWithCriteria(department);
    }

    @GetMapping("/named/{department}")
    public List<Employee> getEmployeesUsingNamedQuery(@PathVariable String department) {
        return employeeRepository.findAll().stream()
                .filter(e -> e.getDepartment().equals(department))
                .toList();
    }
}
