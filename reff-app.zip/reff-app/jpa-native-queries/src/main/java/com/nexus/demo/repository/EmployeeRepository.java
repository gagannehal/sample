package com.nexus.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nexus.demo.entity.Employee;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // JPQL Query
    @Query("SELECT e FROM Employee e WHERE e.salary > :salary")
    List<Employee> findEmployeesWithSalaryGreaterThan(double salary);

    // Native Query
    @Query(value = "SELECT * FROM EMPLOYEE WHERE DEPARTMENT = :department", nativeQuery = true)
    List<Employee> findEmployeesByDepartment(String department);
}
