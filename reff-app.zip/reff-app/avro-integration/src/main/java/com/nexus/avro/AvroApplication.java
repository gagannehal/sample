package com.nexus.avro;


import java.io.File;
import java.io.IOException;
import java.util.Base64;
import java.util.Map;

import org.apache.avro.file.DataFileReader;
import org.apache.avro.file.DataFileWriter;
import org.apache.avro.io.DatumReader;
import org.apache.avro.io.DatumWriter;
import org.apache.avro.specific.SpecificDatumReader;
import org.apache.avro.specific.SpecificDatumWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class AvroApplication {

	public static void main(String[] args) {
		SpringApplication.run(AvroApplication.class, args);
	}

	@GetMapping("/healthcheck")
	public String healthcheck() {
		return "OK";
	}

	@Autowired
    private AvroService avroService;

    @PostMapping("/serialize")
    public String serialize(@RequestBody User user) throws IOException {
        byte[] data = avroService.serialize(user);
        return Base64.getEncoder().encodeToString(data);
    }

	@PostMapping("/deserialize")
	public User deserialize(@RequestBody Map<String, String> requestBody) throws IOException {
    String base64Data = requestBody.get("data");
    byte[] data = Base64.getDecoder().decode(base64Data);
    return avroService.deserialize(data);
	}

	@GetMapping("/genFile")
	public String genFile() throws IOException {
		Customer.Builder customerBuilder = Customer.newBuilder();
        customerBuilder.setAge(99);
        customerBuilder.setFirstName("John");
        customerBuilder.setLastName("Doe");

        Customer customerObj = customerBuilder.build();
        final DatumWriter<Customer> datumWriter = new SpecificDatumWriter<>(Customer.class);

        try (DataFileWriter<Customer> dataFileWriter = new DataFileWriter<>(datumWriter)) {
            dataFileWriter.create(customerObj.getSchema(), new File("customer-specific.avro"));
            dataFileWriter.append(customerObj);
            return "successfully wrote customer-specific.avro";
        } catch (IOException e){
            e.printStackTrace();
			return e.toString();
        }
		
	}

	@GetMapping("/readFile")
	public String readFile() throws IOException {
        // read it from a file
        final File file = new File("customer-specific.avro");
        final DatumReader<Customer> datumReader = new SpecificDatumReader<>(Customer.class);
        final DataFileReader<Customer> dataFileReader;
        try {
			Customer readCustomer = null;
            System.out.println("\nReading our specific record");
            dataFileReader = new DataFileReader<>(file, datumReader);
            while (dataFileReader.hasNext()) {
                readCustomer = dataFileReader.next();
                System.out.println(readCustomer.toString());
                System.out.println("First name: " + readCustomer.getFirstName());
            }
			return readCustomer.toString();
        } catch (IOException e) {
            e.printStackTrace();
			return e.toString();
        }
	}

}
